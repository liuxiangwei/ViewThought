//
//  BaseNavigationController.h
//  TableViewDecoupling
//
//  Created by Secial on 15/4/20.
//  Copyright © 2016年 Liuxiangwei. All rights reserved.
//


/*
 编程到最后传递的就是一种思维方式和思路
 */
#import <UIKit/UIKit.h>

@interface BaseNavigationController : UINavigationController

@end
