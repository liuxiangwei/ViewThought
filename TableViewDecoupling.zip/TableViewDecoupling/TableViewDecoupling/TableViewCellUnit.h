//
//  TableViewCellUnit.h
//  TableViewDecoupling
//
//  Created by Secial on 15/4/20.
//  Copyright © 2016年 Liuxiangwei. All rights reserved.
//


/*
 编程到最后传递的就是一种思维方式和思路
 */
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

typedef UITableViewCell * (^CellRenderBlock)(NSIndexPath *indexPath, UITableView *tableView);
typedef NSIndexPath * (^CellWillSelectBlock)(NSIndexPath *indexPath, UITableView *tableView);
typedef void (^CellSelectionBlock)(NSIndexPath *indexPath, UITableView *tableView);

typedef void (^CellWillDisplayBlock)(UITableViewCell *cell, NSIndexPath *indexPath, UITableView *tableView);
typedef void (^CellCommitEditBlock)(NSIndexPath *indexPath, UITableView *tableView,
                                       UITableViewCellEditingStyle editingStyle);

//TableView Cell定制模型

@interface TableViewCellUnit : NSObject
@property (nonatomic, copy) CellRenderBlock renderBlock;            // 必须实现
@property (nonatomic, copy) CellWillDisplayBlock willDisplayBlock;  // 附加块
@property (nonatomic, copy) CellWillSelectBlock willSelectBlock;    // 附加块
@property (nonatomic, copy) CellWillSelectBlock willDeselectBlock;  //// 附加块
@property (nonatomic, copy) CellSelectionBlock selectionBlock;      //// 附加块
@property (nonatomic, copy) CellSelectionBlock deselectionBlock;    // 附加块
@property (nonatomic, copy) CellCommitEditBlock commitEditBlock;    // 附加块

@property (nonatomic, assign) CGFloat height;
@property (nonatomic, assign) BOOL canEdit;

@property (nonatomic, assign) UITableViewCellEditingStyle editingStyle; //是否支持编辑
@property (nonatomic, copy) NSString *deleteConfirmationButtonTitle;  // 删除确定的title
@end
