//
//  TableViewModelDelegate.m
//  TableViewDecoupling
//
//  Created by Secial on 15/4/20.
//  Copyright © 2015年 Liuxiangwei. All rights reserved.
//



/*
 编程到最后传递的就是一种思维方式和思路
 */
#import "TableViewLayer.h"
#import "TableViewCellUnit.h"
@interface TableViewLayer ()

@end


@implementation TableViewLayer

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.sectionAtTableView = [NSMutableArray array];
    }
    return self;
}

- (TableViewSectionUnit*)sectionModelAtTableViewSection:(NSInteger)section {
    @try {
        TableViewSectionUnit *sectionModel = self.sectionAtTableView[section];
        return sectionModel;
    }
    @catch (NSException *exception) {
        return nil;
    }
}

- (TableViewCellUnit*)cellModelAtTableViewIndexPath:(NSIndexPath *)indexPath {
    @try {
        TableViewSectionUnit *sectionModel = self.sectionAtTableView[indexPath.section];
        TableViewCellUnit *cellModel = sectionModel.cellAtTableView[indexPath.row];
        return cellModel;
    }
    @catch (NSException *exception) {
        return nil;
    }
}

#pragma mark - UITableViewDelegate
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    TableViewCellUnit *cellModel = [self cellModelAtTableViewIndexPath:indexPath];
    return cellModel.height;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    TableViewSectionUnit *sectionModel = [self sectionModelAtTableViewSection:section];
    return sectionModel.headerHeight;
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    TableViewSectionUnit *sectionModel = [self sectionModelAtTableViewSection:section];
    return sectionModel.footerHeight;
}
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    TableViewSectionUnit *sectionModel = [self sectionModelAtTableViewSection:section];
    ViewRenderBlock headerViewRenderBlock = sectionModel.headerViewRenderBlock;
    if (headerViewRenderBlock) {
        return headerViewRenderBlock(section, tableView);
    } else {
        return sectionModel.headerView;
    }
}
- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section {
    TableViewSectionUnit *sectionModel = [self sectionModelAtTableViewSection:section];
    ViewRenderBlock footerViewRenderBlock = sectionModel.footerViewRenderBlock;
    if (footerViewRenderBlock) {
        return footerViewRenderBlock(section, tableView);
    } else {
        return sectionModel.footerView;
    }
}
- (NSIndexPath *)tableView:(UITableView *)tableView
           willSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    TableViewCellUnit *cellModel = [self cellModelAtTableViewIndexPath:indexPath];
    CellWillSelectBlock willSelectBlock = cellModel.willSelectBlock;
    ;
    if (willSelectBlock) {
        return willSelectBlock(indexPath, tableView);
    }
    return indexPath;
}
- (nullable NSIndexPath *)tableView:(UITableView *)tableView
         willDeselectRowAtIndexPath:(NSIndexPath *)indexPath {
    TableViewCellUnit *cellModel = [self cellModelAtTableViewIndexPath:indexPath];
    CellWillSelectBlock willDeselectBlock = cellModel.willDeselectBlock;
    ;
    if (willDeselectBlock) {
        return willDeselectBlock(indexPath, tableView);
    }
    return indexPath;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    TableViewCellUnit *cellModel = [self cellModelAtTableViewIndexPath:indexPath];
    CellSelectionBlock selectionBlock = cellModel.selectionBlock;
    if (selectionBlock) {
        selectionBlock(indexPath, tableView);
    }
}
- (void)tableView:(UITableView *)tableView didDeselectRowAtIndexPath:(NSIndexPath *)indexPath {
    TableViewCellUnit *cellModel = [self cellModelAtTableViewIndexPath:indexPath];
    CellSelectionBlock deselectionBlock = cellModel.deselectionBlock;
    if (deselectionBlock) {
        deselectionBlock(indexPath, tableView);
    }
}
- (NSString *)tableView:(UITableView *)tableView titleForDeleteConfirmationButtonForRowAtIndexPath:(NSIndexPath *)indexPath {
    TableViewCellUnit *cellModel = [self cellModelAtTableViewIndexPath:indexPath];
    return cellModel.deleteConfirmationButtonTitle;
}

#pragma mark - UITableViewDataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return self.sectionAtTableView.count;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    TableViewSectionUnit *sectionModel = [self sectionModelAtTableViewSection:section];
    return sectionModel.cellAtTableView.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    TableViewCellUnit *cellModel = [self cellModelAtTableViewIndexPath:indexPath];
    UITableViewCell *cell = nil;
    CellRenderBlock renderBlock = cellModel.renderBlock;
    if (renderBlock) {
        cell = renderBlock(indexPath, tableView);
    }
    return cell;
}
- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
    TableViewCellUnit *cellModel = [self cellModelAtTableViewIndexPath:indexPath];
    CellWillDisplayBlock willDisplayBlock = cellModel.willDisplayBlock;
    if (willDisplayBlock) {
        willDisplayBlock(cell, indexPath, tableView);
    }
}
- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    TableViewSectionUnit *sectionModel = [self sectionModelAtTableViewSection:section];
    return sectionModel.headerTitle;
}
- (NSString *)tableView:(UITableView *)tableView titleForFooterInSection:(NSInteger)section {
    TableViewSectionUnit *sectionModel = [self sectionModelAtTableViewSection:section];
    return sectionModel.footerTitle;
}
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    TableViewCellUnit *cellModel = [self cellModelAtTableViewIndexPath:indexPath];
    return cellModel.canEdit;
}
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath{
    TableViewCellUnit *cellModel = [self cellModelAtTableViewIndexPath:indexPath];
    CellCommitEditBlock commitEditBlock = cellModel.commitEditBlock;
    if (commitEditBlock) {
        commitEditBlock(indexPath, tableView, editingStyle);
    }
}

@end
