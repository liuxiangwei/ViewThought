//
//  MainViewController.h
//  TableViewDecoupling
//
//  Created by Secial on 15/4/20.
//  Copyright © 2016年 Liuxiangwei. All rights reserved.
//

/*
 编程到最后传递的就是一种思维方式和思路
 */

#import <UIKit/UIKit.h>

#include "TableViewLayer.h"


typedef NS_ENUM(NSInteger, MemberType) {
    MemberTypeEmployee,
    MemberTypeManager,
};



@interface MainViewController : UITableViewController
@property (nonatomic, assign) MemberType type;
- (void)showAlertWithTitle:(NSString *)title andMessage:(NSString *)msg;

@end
