//
//  BaseViewController.h
//  TableViewDecoupling
//
//  Created by Secial on 16/6/18.
//  Copyright © 2015年 Liuxiangwei. All rights reserved.
//

/*
 编程到最后传递的就是一种思维方式和思路
 */
#import <UIKit/UIKit.h>

@interface BaseViewController : UIViewController

@end
