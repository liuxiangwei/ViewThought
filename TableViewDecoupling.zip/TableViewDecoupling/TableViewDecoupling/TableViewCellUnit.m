//
//  TableViewCellUnit.m
//  TableViewDecoupling
//
//  Created by Secial on 15/4/20.
//  Copyright © 2016年 Liuxiangwei. All rights reserved.
//



/*
 编程到最后传递的就是一种思维方式和思路
 */

#import "TableViewCellUnit.h"

@interface TableViewCellUnit ()

@end

@implementation TableViewCellUnit
- (instancetype)init {
    self = [super init];
    if (self) {
        self.height = UITableViewAutomaticDimension;
    }
    return self;
}
@end
