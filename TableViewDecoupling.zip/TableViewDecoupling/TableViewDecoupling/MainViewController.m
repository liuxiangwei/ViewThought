//
//  MainViewController.m
//  TableViewDecoupling
//
//  Created by Secial on 15/4/20.
//  Copyright © 2016年 Liuxiangwei. All rights reserved.
//

#import "MainViewController.h"
#import "TableViewLayer.h"
#import "TableViewSectionUnit.h"
#import "TableViewCellUnit.h"
#import "Macro.h"

/*
编程到最后传递的就是一种思维方式和思路
 */


static NSString *Identify_CellWithImage = @"CellWithImage";
static NSString *Identify_EntryCell = @"EntryCell";
static NSString *Identify_CellWithBigFont = @"CellWithBigFont";

@interface MainViewController ()
@property(strong,nonatomic)TableViewLayer* tableViewModelLayer;

- (void)initTableViewStytle;
@end

@implementation MainViewController

- (void)viewDidLoad{
    [super viewDidLoad];
    self.title=@"TableView分层模型";
    self.view.backgroundColor=[UIColor lightGrayColor];
    self.tableViewModelLayer = [[TableViewLayer alloc]init];
    self.tableView.delegate = self.tableViewModelLayer;
    self.tableView.dataSource = self.tableViewModelLayer;
    
    [self initTableViewStytle];
    [self.tableView reloadData];
}

- (void)initTableViewStytle {
    [self.tableViewModelLayer.sectionAtTableView removeAllObjects];
    [self.tableViewModelLayer.sectionAtTableView addObject:[self storeInfoSection]];
    if (self.type == MemberTypeManager) {
        [self.tableViewModelLayer.sectionAtTableView addObject:[self advancedSettinsSection]];
    }
    [self.tableViewModelLayer.sectionAtTableView addObject:[self incomeInfoSection]];
    [self.tableViewModelLayer.sectionAtTableView addObject:[self otherSection]];
}

- (TableViewSectionUnit*)storeInfoSection {
    YZWeak(self);
    TableViewSectionUnit *sectionModel = [[TableViewSectionUnit alloc] init];
    sectionModel.headerTitle = @"存储信息";
    sectionModel.headerHeight = 40;
    sectionModel.footerHeight = 0.1;
    
    
    TableViewCellUnit *cellModel = [[TableViewCellUnit alloc] init];
    [sectionModel.cellAtTableView addObject:cellModel];
    cellModel.height = 80;
    cellModel.renderBlock = ^UITableViewCell *(NSIndexPath *indexPath, UITableView *tableView) {
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:Identify_CellWithImage];
        if (!cell) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault
                                          reuseIdentifier:Identify_CellWithImage];
            UIImageView *iconView =
            [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"store"]];
            iconView.frame = CGRectMake(10, 10, 60, 60);
            iconView.tag = 1;
            [cell.contentView addSubview:iconView];
            UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(80, 5, 250, 40)];
            titleLabel.font = [UIFont boldSystemFontOfSize:20];
            titleLabel.tag = 2;
            [cell.contentView addSubview:titleLabel];
            UILabel *descLabel = [[UILabel alloc] initWithFrame:CGRectMake(80, 45, 250, 25)];
            descLabel.tag = 3;
            [cell.contentView addSubview:descLabel];
        }
        UILabel *titleLabel = (UILabel *)[cell.contentView viewWithTag:2];
        titleLabel.text = @"Mac在线";
        UILabel *descLabel = (UILabel *)[cell.contentView viewWithTag:3];
        descLabel.text = @"在线活动";
        return cell;
    };
    if (self.type == MemberTypeManager) {
        // product list cell
        TableViewCellUnit *cellModel = [[TableViewCellUnit alloc] init];
        [sectionModel.cellAtTableView addObject:cellModel];
        cellModel.renderBlock = ^UITableViewCell *(NSIndexPath *indexPath, UITableView *tableView) {
            UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:Identify_EntryCell];
            if (!cell) {
                cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault
                                              reuseIdentifier:Identify_EntryCell];
                cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
            }
            cell.textLabel.text = @"所有成品";
            return cell;
        };
        cellModel.selectionBlock = ^(NSIndexPath *indexPath, UITableView *tableView) {
            [tableView deselectRowAtIndexPath:indexPath animated:YES];
            YZStrong(self);
            [self showAlertWithTitle:@"" andMessage:@"产品详情"];
        };
    }
    return sectionModel;
}

- (TableViewSectionUnit*)advancedSettinsSection {
    YZWeak(self);
    TableViewSectionUnit *sectionModel = [[TableViewSectionUnit alloc] init];
    sectionModel.headerTitle = @"设置";
    sectionModel.headerHeight = 40;
    sectionModel.footerHeight = 0.1;
    
    TableViewCellUnit *cellModel = [[TableViewCellUnit alloc] init];
    [sectionModel.cellAtTableView addObject:cellModel];
    cellModel.renderBlock = ^UITableViewCell *(NSIndexPath *indexPath, UITableView *tableView) {
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:Identify_EntryCell];
        if (!cell) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault
                                          reuseIdentifier:Identify_EntryCell];
            cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        }
        cell.textLabel.text = @"店面装修";
        return cell;
    };
    cellModel.selectionBlock = ^(NSIndexPath *indexPath, UITableView *tableView) {
        [tableView deselectRowAtIndexPath:indexPath animated:YES];
        YZStrong(self);
        [self showAlertWithTitle:@"" andMessage:@"装修详情"];
    };

    
    cellModel = [[TableViewCellUnit alloc] init];
    [sectionModel.cellAtTableView addObject:cellModel];
    cellModel.renderBlock = ^UITableViewCell *(NSIndexPath *indexPath, UITableView *tableView) {
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:Identify_EntryCell];
        if (!cell) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault
                                          reuseIdentifier:Identify_EntryCell];
            cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        }
        cell.textLabel.text = @"仓库地址";
        return cell;
    };
    cellModel.selectionBlock = ^(NSIndexPath *indexPath, UITableView *tableView) {
        [tableView deselectRowAtIndexPath:indexPath animated:YES];
        YZStrong(self);
        [self showAlertWithTitle:@"" andMessage:@"进入"];
    };

    
    
    cellModel = [[TableViewCellUnit alloc] init];
    [sectionModel.cellAtTableView addObject:cellModel];
    cellModel.renderBlock = ^UITableViewCell *(NSIndexPath *indexPath, UITableView *tableView) {
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:Identify_EntryCell];
        if (!cell) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault
                                          reuseIdentifier:Identify_EntryCell];
            cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        }
        cell.textLabel.text = @"开放日期";
        return cell;
    };
    cellModel.selectionBlock = ^(NSIndexPath *indexPath, UITableView *tableView) {
        [tableView deselectRowAtIndexPath:indexPath animated:YES];
        YZStrong(self);
        [self showAlertWithTitle:@"" andMessage:@"进入"];
    };
    return sectionModel;
}

- (TableViewSectionUnit*)incomeInfoSection {
    YZWeak(self);
    TableViewSectionUnit *sectionModel = [[TableViewSectionUnit alloc] init];
    sectionModel.headerTitle = @"收支情况";
    sectionModel.headerHeight = 40;
    sectionModel.footerHeight = 0.1;
    if (self.type == MemberTypeManager) {
        // Withdraw
        TableViewCellUnit *cellModel = [[TableViewCellUnit alloc] init];
        [sectionModel.cellAtTableView addObject:cellModel];
        cellModel.height = 60;
        cellModel.renderBlock = ^UITableViewCell *(NSIndexPath *indexPath, UITableView *tableView) {
            UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:Identify_CellWithBigFont];
            if (!cell) {
                cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault
                                              reuseIdentifier:Identify_CellWithBigFont];
                cell.accessoryType = UITableViewCellAccessoryNone;
                cell.textLabel.font = [UIFont boldSystemFontOfSize:22];
                cell.textLabel.textAlignment = NSTextAlignmentCenter;
            }
            cell.textLabel.text = @"撤销订单";
            return cell;
        };
        cellModel.selectionBlock = ^(NSIndexPath *indexPath, UITableView *tableView) {
            [tableView deselectRowAtIndexPath:indexPath animated:YES];
            YZStrong(self);
            [self showAlertWithTitle:@"" andMessage:@"退款"];
        };
    }

    
    TableViewCellUnit *cellModel = [[TableViewCellUnit alloc] init];
    [sectionModel.cellAtTableView addObject:cellModel];
    cellModel.renderBlock = ^UITableViewCell *(NSIndexPath *indexPath, UITableView *tableView) {
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:Identify_EntryCell];
        if (!cell) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault
                                          reuseIdentifier:Identify_EntryCell];
            cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        }
        cell.textLabel.text = @"订单";
        return cell;
    };
    cellModel.selectionBlock = ^(NSIndexPath *indexPath, UITableView *tableView) {
        [tableView deselectRowAtIndexPath:indexPath animated:YES];
        YZStrong(self);
        [self showAlertWithTitle:@"" andMessage:@"订单详情"];
    };
    // Income
    cellModel = [[TableViewCellUnit alloc] init];
    [sectionModel.cellAtTableView addObject:cellModel];
    cellModel.renderBlock = ^UITableViewCell *(NSIndexPath *indexPath, UITableView *tableView) {
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:Identify_EntryCell];
        if (!cell) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault
                                          reuseIdentifier:Identify_EntryCell];
            cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        }
        cell.textLabel.text = @"收入";
        return cell;
    };
    cellModel.selectionBlock = ^(NSIndexPath *indexPath, UITableView *tableView) {
        [tableView deselectRowAtIndexPath:indexPath animated:YES];
        YZStrong(self);
        [self showAlertWithTitle:@"" andMessage:@"账单"];
    };
    return sectionModel;
}

- (TableViewSectionUnit*)otherSection {
    YZWeak(self);
    TableViewSectionUnit *sectionModel = [[TableViewSectionUnit alloc] init];
    sectionModel.headerTitle = @"其他";
    sectionModel.headerHeight = 40;
    sectionModel.footerHeight = 40;

    
    
    TableViewCellUnit *cellModel = [[TableViewCellUnit alloc] init];
    [sectionModel.cellAtTableView addObject:cellModel];
    cellModel.renderBlock = ^UITableViewCell *(NSIndexPath *indexPath, UITableView *tableView) {
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:Identify_EntryCell];
        if (!cell) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault
                                          reuseIdentifier:Identify_EntryCell];
            cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        }
        cell.textLabel.text = @"关于";
        return cell;
    };
    cellModel.selectionBlock = ^(NSIndexPath *indexPath, UITableView *tableView) {
        [tableView deselectRowAtIndexPath:indexPath animated:YES];
        YZStrong(self);
        [self showAlertWithTitle:@"" andMessage:@"关于"];
    };
    return sectionModel;
}

- (void)showAlertWithTitle:(NSString *)title andMessage:(NSString *)msg {
    if (NSClassFromString(@"UIAlertController")) {
        UIAlertController *alertController =
        [UIAlertController alertControllerWithTitle:title
                                            message:msg
                                     preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *ok =
        [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:nil];
        [alertController addAction:ok];
        [self presentViewController:alertController animated:YES completion:nil];
    } else {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title message:msg delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil];
        [alert show];
    }
}
@end
