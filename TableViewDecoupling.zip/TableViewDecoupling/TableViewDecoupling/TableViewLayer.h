//
//  TableViewModelDelegate.h
//  TableViewDecoupling
//
//  Created by Secial on 15/4/20.
//  Copyright © 2015年 Liuxiangwei. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "TableViewSectionUnit.h"
/*
 编程到最后传递的就是一种思维方式和思路
 */

//TableView代理模型
@interface TableViewLayer : NSObject<UITableViewDelegate,UITableViewDataSource>
@property(strong,nonatomic)NSMutableArray<TableViewSectionUnit*> * sectionAtTableView;
@end
