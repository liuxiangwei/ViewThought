//
//  BaseViewController.m
//  TableViewDecoupling
//
//  Created by Secial on 16/6/18.
//  Copyright © 2015年 Liuxiangwei. All rights reserved.
//

/*
 编程到最后传递的就是一种思维方式和思路
 */

#import "BaseViewController.h"

@interface BaseViewController ()

@end

@implementation BaseViewController
- (void)viewDidLoad{
    [super viewDidLoad];
}
@end
