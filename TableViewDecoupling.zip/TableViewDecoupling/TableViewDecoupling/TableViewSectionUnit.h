//
//  TableViewSectionUnit.h
//  TableViewDecoupling
//
//  Created by Secial on 15/4/20.
//  Copyright © 2015年 Liuxiangwei. All rights reserved.
//



/*
 编程到最后传递的就是一种思维方式和思路
 */
#import <Foundation/Foundation.h>
#import <UIkit/UIKit.h>

@class TableViewCellUnit;
typedef UIView * (^ViewRenderBlock)(NSInteger section, UITableView *tableView);

//TableView Section定制模型
@interface TableViewSectionUnit : NSObject
@property (nonatomic, strong) NSMutableArray<TableViewCellUnit *> *cellAtTableView;
@property (nonatomic, strong) NSString *headerTitle;  // 附加属性
@property (nonatomic, strong) NSString *footerTitle;  // 附加属性
//以下属性可采用默认值
@property (nonatomic, assign) CGFloat headerHeight;
@property (nonatomic, assign) CGFloat footerHeight;


// 渲染TableView Header
@property (nonatomic, copy) ViewRenderBlock headerViewRenderBlock;
// 渲染TableView Footer
@property (nonatomic, copy) ViewRenderBlock footerViewRenderBlock;
// view
@property (nonatomic, strong) UIView *headerView;
@property (nonatomic, strong) UIView *footerView;
@end
